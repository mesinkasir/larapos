<?php $__env->startSection('content'); ?>
	
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">All Categories</div>

                <div class="panel-body">
                   
                    <table class="table table-striped">
							<thead>
							  <tr>
								<th>ID</th>
								<th>Category Name</th>
								<th>Category Code</th>
								<th>Image</th>
								<th>Edit</th>
								<th>Delete</th>
							  </tr>
							</thead>
							<tbody>
						  	  <?php foreach($categories as $category): ?>
								  <tr>
								    <td><?php echo $category->id; ?></td>
									<td><?php echo $category->name; ?></td>
									<td><?php echo $category->code; ?></td>
									<td><?php echo Html::image($category->image ,$category->title, array('width'=>'50','height' =>'50')); ?></td>
									
									<td>
										
										<?php echo Form::open(array('url' => "/category/$category->id/edit" , 'method' => 'GET')); ?>

											<?php echo Form::hidden('id', $category->id); ?>

												<button type="submit" class="btn btn-default">Edit</button>
										<?php echo Form::close(); ?>

									</td>
									<td>
										<?php echo Form::open(array('url' => '/category/destroy' ,  'method' => 'delete')); ?>

											<?php echo Form::hidden('id', $category->id); ?>

												<button type="submit" class="btn btn-default">Delete</button>
										<?php echo Form::close(); ?>

									</td>
								  </tr>
							  <?php endforeach; ?>
							  <a type="submit" class="btn btn-default" href="http://localhost/pos/category/create">Add New Category</a>
							</tbody>
						  </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>