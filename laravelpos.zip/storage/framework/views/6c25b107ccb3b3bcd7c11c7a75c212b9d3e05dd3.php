<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Welcome</div>
				
                <div class="panel-body">
                    <div>
					  <label>Name:</label>
					  <input type="text" ng-model="yourName" placeholder="Enter a name here">
					  <hr>
					  <h1>Hello {{ yourName }} !</h1>
						<div class="panel-body">
							<input type="text" ng-model="data.test" placeholder="What..">
								Hello {{ data.test  }}
							<hr>
							<button class="{{ data.test }} btn btn-lg"> I'm BTN</button>
						</div>
					</div>
                    <?php if(!Auth::guest() && Auth::user()->admin): ?>
                    	<a class="btn btn-primary" href="<?php echo e(url('/orders')); ?>">Place Order</a>
                    	<a class="btn btn-primary" href="<?php echo e(url('/users/create')); ?>">Register</a>
                    	<a class="btn btn-primary" href="<?php echo e(url('/users/')); ?>">Show All Users</a>
                    	<a class="btn btn-primary" href="<?php echo e(url('/shop')); ?>">Shop</a>
                    	<a class="btn btn-primary" href="<?php echo e(url('/product')); ?>">Show All Products</a>
                    	<a class="btn btn-primary" href="<?php echo e(url('/product/create')); ?>">Add Product</a>
                    	<a class="btn btn-primary" href="<?php echo e(url('/category/create')); ?>">Add Category</a>
                    	<a class="btn btn-raised btn-primary" href="<?php echo e(url('/category')); ?>">Show All Categories</a>
                    	<hr>
                    	<a class="btn btn-raised btn-default" href="<?php echo e(url('/settings')); ?>"> Settings</a>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>