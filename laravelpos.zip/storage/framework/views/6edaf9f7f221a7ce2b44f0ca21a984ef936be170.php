<?php $__env->startSection('content'); ?>
	
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Products</div>

                <div class="panel-body">
                   
                    <table class="table table-striped">
							<thead>
							  <tr>
								<th>ID</th>
								<th>Company Name</th>
								<th>Edit</th>
							  </tr>
							</thead>
							<tbody>
						  	
								  <tr>
								    <td><?php echo $company->id; ?></td>
									<td><?php echo $company->companyname; ?></td>
									<td>
										
										<?php echo Form::open(array('url' => "/settings/$company->id/edit" , 'method' => 'GET')); ?>

											<?php echo Form::hidden('id', $company->id); ?>

												<button type="submit" class="btn btn-default">Edit</button>
										<?php echo Form::close(); ?>

									</td>
								
								  </tr>
							
							</tbody>
						  </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>